import profile from "./hospital-1.jpg";
import profile1 from "./hospital-2.jpg";
import profile2 from "./hospital-3.jpg";

export const cardData = [
  {
    id: 1,
    Header: "What Pepole say About Us",
    carosalImage: profile,
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
    titleName: "Dipak",
    job: "Detroit Michigan",
  },
  {
    id: 2,
    Header: "How can you helf you",
    carosalImage: profile1,
    content:
      "Learn for past plane for future but leave in present becouse present is befor you.",
    titleName: "Kamlesh",
    job: "Devlopar web",
  },
  {
    id: 3,
    Header: "All DRs Details Us",
    carosalImage: profile2,
    content:
      "WE ALl of We offer flexible appoinment scheaduliing and free to accommodate your busy life",
    titleName: "Vikash",
    job: "Directer of Compny",
  },
];
