import Headphone from "./Headphone.png";
import StesCaop from "./stescoop.png";
import Star from "./star.png";
import Bed from "./bed.png";

export const cardData = [
  {
    id: 1,
    cardImag: Headphone,
    title: "Free Consultation",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
  {
    id: 2,
    cardImag: StesCaop,
    title: "Expert Dentist",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
  {
    id: 3,
    cardImag: Star,
    title: "High User Reating",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
  {
    id: 4,
    cardImag: Bed,
    title: "Best Equipment",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
];
