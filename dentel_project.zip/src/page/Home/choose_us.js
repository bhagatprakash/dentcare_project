import React from "react";

function ChooseUs() {
  return <div>Choose_us</div>;
}

export default ChooseUs;
