import React from "react";

function Treatment() {
  return <div>Treatment</div>;
}

export default Treatment;
