import React from "react";

function Consolation() {
  return <div>Consolation</div>;
}

export default Consolation;
