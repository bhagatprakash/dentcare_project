export const cardData = [
  {
    id: 1,
    cardImag:
      "https://icons.veryicon.com/png/o/business/security-mobile-terminal-icon/online-consultation.png",
    title: "Free Consultation",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
  {
    id: 2,
    cardImag:
      "https://e7.pngegg.com/pngimages/474/160/png-clipart-physician-doctor-of-medicine-stethoscope-computer-icons-stetoskop-miscellaneous-dentistry.png",
    title: "Expert Dentist",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
  {
    id: 3,
    cardImag:
      "https://static-00.iconduck.com/assets.00/star-rating-icon-2048x2048-2k1x57ky.png",
    title: "High User Reating",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
  {
    id: 4,
    cardImag:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8DY35Bxz73mGFOQeetN08MxrN8yiaC9LvfaeZGMjkXw&s",
    title: "Best Equipment",
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
  },
];
