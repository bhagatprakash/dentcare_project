import React from "react";

function Footer() {
  return (
    <>
      <div className="max-w-[1320px] md:py-[80] py-10 flex mx-auto sm:flex-row flex-col">
        <div className="grid grid-cols-4 gap-5 my-10 px-10">
          <div>
            <h1 className="text-xl font-semibold ">Company</h1>
            <p className="text-red-500">Home</p>
            <p className="">Services</p>
            <p className="">About Us</p>
            <p className="">Why Choose Us</p>
            <p className="">Testimonials</p>
            <p className="">Contact Us</p>
          </div>
          <div>
            <h1 className="text-xl font-semibold ">Pages</h1>
            <p className="">404</p>
            <p className="">Licensing</p>
            <p className="">Instructions</p>
            <p className="">Style Guide</p>
            <p className="">ChangeLog</p>
            <p className="">More Templates!</p>
          </div>

          <div>
            <h1 className="text-xl font-semibold ">Address</h1>
            <p className="">
              123 Dental Avenue City Ville State 12345 United States
            </p>
            <p className="">View Maps</p>
            <h1 className="text-xl font-semibold ">Inquiries</h1>
            <p className="">(123) 456-7800</p>
            <p className="">info@57dentcare.com</p>
          </div>

          <div>
            <h1 className="text-xl font-semibold ">Newsletter</h1>
            <p className="">stay updated whith our Latest News</p>
            <input
              type="Text"
              placeholder="Your Email"
              className="border border-gray-400 py-1 h-[45px] w-[300px] px-2  rounded-[20px]  font-semibold "
            />
            <h1 className="text-xl font-semibold ">Follow Us</h1>
            <p className="">(123) 456-7800</p>
            <p className="">info@57dentcare.com</p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Footer;
