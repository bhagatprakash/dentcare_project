import React from "react";

function Testmonials() {
  return <div>Testmonials</div>;
}

export default Testmonials;
