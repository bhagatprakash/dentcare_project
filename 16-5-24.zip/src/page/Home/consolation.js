import React from "react";
import img from "../../Assect/banner_img.png";

function Consolation() {
  return (
    <>
      <div className="max-w-[1320px] md:py-[80] py-10 flex mx-auto sm:flex-row flex-col sm:my-4">
        <div className="basis-[50%] pb-5 bg-gray-200  shadow-2xl  rounded-l-xl">
          <img src={img} alt="about ima" className="w-full" />
        </div>
        <div className="basis-[50%] shadow-2xl bg-white  rounded-r-xl">
          <div className="max-auto text-center my-5">
            <h1 className="text-4xl font-semibold">Free Consultation</h1>
          </div>
          <div className="  #">
            <form action="#">
              <div className="grid grid-cols-2 gap-5 my-10 px-10">
                <input
                  type="text"
                  placeholder="Full Name"
                  className="border border-gray-400 py-1 h-[65px] px-2  rounded-[20px] text-center"
                />
                <input
                  type="text"
                  placeholder="I am intersted in"
                  className="border border-gray-400 py-1 px-2  h-[65px] text-center  rounded-[20px]"
                />
              </div>
              <div className="grid grid-cols-2 gap-5 my-10 px-10">
                <input
                  type="Text"
                  placeholder="Email"
                  className="border border-gray-400 py-1 h-[65px] px-2  rounded-[20px] text-center"
                />
                <input
                  type="text"
                  placeholder="phone Numbar"
                  className="border border-gray-400 py-1 px-2  h-[65px] text-center  rounded-[20px]"
                />
              </div>
            </form>

            <div className="text-center">
              <button className="btn mt-4 text-xl  h-[65px] w-[580px] rounded-[18px] font-semibold  bg-green-400 lg:mt-6">
                Booking Now <i className="fa-solid fa-arrow-trend-down"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Consolation;
