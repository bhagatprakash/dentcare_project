import React from "react";
import img from "../../Assect/banner_img.png";

function AboutUs() {
  return (
    <>
      <div className="max-w-[1320px] md:py-[80] py-10 flex mx-auto sm:flex-row flex-col">
        <div className="basis-[49%] pb-5 bg-orange-200 rounded-bl-[50px]  rounded-tr-[50px]">
          <img src={img} alt="about ima" className="w-full" />
        </div>
        <div className="basis-[49%] px-5">
          <p className="text-xl text-green-500 font-semibold">About Us</p>
          <h1 className="text-4xl  font-semibold">Patient-Centered Care</h1>
          <p className="text-xl my-10">
            "To succeed in your mission, you must have single-minded devotion to
            your goal." In pic: A boy holds a mask bearing the image of former
            Indian president APJ Abdul Kalam and a sapling during his death
            anniversary.
          </p>
          <h1 className="text-2xl  font-semibold">Our Mission</h1>
          <p className="text-xl my-2">
            When you focus on problems, you'll have more problems.{" "}
          </p>

          <button className="btn font-semibold my-5 bg-green-500 h-[50px] w-[150px]  rounded">
            Learn More <i className="fa-solid fa-arrow-trend-down"></i>
          </button>
        </div>
      </div>
    </>
  );
}

export default AboutUs;
