import React from "react";
import img from "../../Assect/banner_img.png";

function Treatment() {
  return (
    <>
      <div className=" ">
        <div>
          <h1 className=" text-xl text-center py-5 text-green-300  font-semibold">
            Satisfy Solution
          </h1>
          <h1 className="text-4xl text-center  font-semibold ">
            The Best Dental Treatment
          </h1>
        </div>

        <div className=" container  max-w-[1100] grid lg:grid-cols-3 md:grid-cols-2 gap-5 py-10 lg:px-[30px] mx-7">
          {/* card-1  */}
          <div className="flex shadow-lg bg-orange-200 w-[500px] rounded-3xl">
            <div className="my-20 w-[200px] mx-10">
              <h1 className="text-4xl py-5 font-semibold">Teeth Whitening</h1>
              <p className="py-2 text-2xl">
                consmetic tretment to enhance the whiteness of teeth
              </p>
              <button className="btn font-semibold bg-white h-[50px] w-[150px]  rounded">
                Read More
              </button>
            </div>
            <div className="absolute my-20 ">
              <img
                src={img}
                alt="image"
                className="relative mt-10 ml-5 w-full"
              />
            </div>
          </div>
          {/* card-2 */}
          <div className="flex shadow-lg bg-pink-200 w-[500px] rounded-3xl">
            <div className="my-20 w-[200px] px-10">
              <h1 className="text-4xl py-5 font-semibold">Teeth Whitening</h1>
              <p className="py-2 text-2xl">
                consmetic tretment to enhance the whiteness of teeth
              </p>
              <button className="btn font-semibold bg-white h-[50px] w-[150px]  rounded">
                Read More
              </button>
            </div>
            <div className="absolute my-20 ">
              <img src={img} alt="image" className="relative mt-10 ml-5" />
            </div>
          </div>

          {/* card-3  */}
          <div className="flex shadow-lg bg-blue-200 w-[500px] rounded-3xl">
            <div className="my-20 w-[200px] px-10">
              <h1 className="text-4xl py-5 font-semibold">Teeth Whitening</h1>
              <p className="py-2 text-2xl">
                consmetic tretment to enhance the whiteness of teeth
              </p>
              <button className="btn font-semibold bg-white h-[50px] w-[150px]  rounded">
                Read More
              </button>
            </div>
            <div className="absolute py-20 ">
              <img src={img} alt="image" className="relative mt-10 ml-10 f-" />
            </div>
          </div>
          {/* card-4  */}
          <div className="flex shadow-lg bg-pink-200 w-[500px] rounded-3xl">
            <div className="my-20 w-[200px] px-10">
              <h1 className="text-4xl py-5 font-semibold">Teeth Whitening</h1>
              <p className="py-2 text-2xl">
                consmetic tretment to enhance the whiteness of teeth
              </p>
              <button className="btn font-semibold bg-white h-[50px] w-[150px]  rounded">
                Read More
              </button>
            </div>
            <div className="absolute py-20 ">
              <img src={img} alt="image" className="relative mt-10 ml-10" />
            </div>
          </div>
          {/* card-5  */}
          <div className="flex shadow-lg bg-blue-200 w-[500px] rounded-3xl">
            <div className="my-20 w-[200px] px-10">
              <h1 className="text-4xl py-5 font-semibold">Teeth Whitening</h1>
              <p className="py-2 text-2xl">
                consmetic tretment to enhance the whiteness of teeth
              </p>
              <button className="btn font-semibold bg-white h-[50px] w-[150px]  rounded">
                Read More
              </button>
            </div>
            <div className="absolute py-20 ">
              <img src={img} alt="image" className="relative mt-10 ml-10" />
            </div>
          </div>
          {/* card-6  */}
          <div className="flex shadow-lg bg-orange-200 w-[500px] rounded-3xl">
            <div className="my-20 w-[200px] px-10">
              <h1 className="text-4xl py-5 font-semibold">Teeth Whitening</h1>
              <p className="py-2 text-2xl">
                consmetic tretment to enhance the whiteness of teeth
              </p>
              <button className="btn font-semibold bg-white h-[50px] w-[150px]  rounded">
                Read More
              </button>
            </div>
            <div className="absolute py-20 ">
              <img src={img} alt="image" className="relative mt-10 ml-10" />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Treatment;
