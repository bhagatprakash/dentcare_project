import React from "react";
import profile from "../../Assect/profile-removebg-preview.png";
// import img from "../../Assets/hospital-1.jpg";
// import img1 from "../../Assets/hospital-2.jpg";
// import img2 from "../../Assets/hospital-3.jpg";

// owl carosal
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";

function Testimonials() {
  const options = {
    items: 2,
    loop: true,
    autoplay: true,
    autoplayTimeout: 4000,
    nav: true,
    dots: false,
    margin: 0,
    responsive: {
      1100: {
        items: 2,
      },
      724: {
        items: 1,
      },
      500: {
        items: 1,
      },
      370: {
        items: 1,
        innerWidth: "100%",
        outerWidth: "100%",
      },
    },
  };
  return (
    <>
      <OwlCarousel className="owl-theme" loop margin={10} nav {...options}>
        <div className="max-w-[1320px] md:py-20  py-10  flex flex-col md:flex-row mx-auto my-4">
          <div className="item  ">
            <div className="item  text-center w-[800px] px-10">
              <h2 className="text-xl font-semibold">Testimonials</h2>
              <h1 className="text-3xl font-semibold">
                What People Say About Us
              </h1>
              <img
                src={profile}
                className=" !h-[300px] !w-[300px] mx-auto  rounded-[50%]"
                alt="Rounded Image"
              />

              <h1 className="text-3xl font-semibold">
                The eleventh president of India and one of the most loved
                president by the children in our country is APJ Abdul Kalam.
              </h1>

              <div className="mx-auto text-center my-10">
                <h1 className="text-2xl font-semibold">Dipak pal</h1>
                <h1 className="text-2xl">Detroit, Michigan</h1>
              </div>
            </div>
          </div>
        </div>
      </OwlCarousel>
    </>
  );
}

export default Testimonials;
